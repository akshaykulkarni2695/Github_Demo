package Com.algorithm;
import java.io.File;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import org.apache.commons.io.FileUtils;

public class Cryptograpy{
    public static File main(File file) {

        try{
            KeyGenerator keygenerator = KeyGenerator.getInstance("DES");
            SecretKey myDesKey = keygenerator.generateKey();

            Cipher desCipher;
            desCipher = Cipher.getInstance("DES");

           // FileInputStream fis = new FileInputStream(file);
            
            byte[] text = file.getName().getBytes("UTF8");
            		


            desCipher.init(Cipher.ENCRYPT_MODE, myDesKey);
            byte[] textEncrypted = desCipher.doFinal(text);

            String s = new String(textEncrypted);
			FileUtils.writeByteArrayToFile(file,textEncrypted);
            System.out.println(s);

          
        }catch(Exception e)
        {
            System.out.println("Exception");
        }
		return file;
    }
}