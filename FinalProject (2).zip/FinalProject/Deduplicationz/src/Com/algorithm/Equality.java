package Com.algorithm;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.util.Arrays;

public class Equality {
	public static boolean CompareFilesbyByte(File file, File filedetails) throws IOException {
		/*
		 * File f1=new File(file1); File f2=new File(filedetails);
		 */
		System.out.println("Equality.CompareFilesbyByte()");
		System.err.println(file.getName());
		System.out.println("does exist (equality) "+file.exists());
		FileInputStream fis1 = new FileInputStream(file);
		
		FileInputStream fis2 = new FileInputStream(filedetails);
		if (file.length() == filedetails.length()) {
			int n = 0;
			byte[] b1;
			byte[] b2;
			while ((n = fis1.available()) > 0) {
				if (n > 80)
					n = 80;
				b1 = new byte[n];
				b2 = new byte[n];
				fis1.read(b1);
				fis2.read(b2);
				if (Arrays.equals(b1, b2) == false) {
					System.out.println(file + " :\n\n " + new String(b1));
					System.out.println();
					System.out.println(filedetails + " : \n\n" + new String(b2));
					return false;
				}
			}
		} else
			return false; // length is not matched.
		return true;
	}

	public static String MD5HashFile(String filename) throws Exception {
		byte[] buf = ChecksumFile(filename);
		String res = "";
		for (int i = 0; i < buf.length; i++) {
			res += Integer.toString((buf[i] & 0xff) + 0x100, 16).substring(1);
		}
		return res;
	}

	public static byte[] ChecksumFile(String filename) throws Exception {
		InputStream fis = new FileInputStream(filename);
		byte[] buf = new byte[1024];
		MessageDigest complete = MessageDigest.getInstance("MD5");
		int n;
		do {
			n = fis.read(buf);
			if (n > 0) {
				complete.update(buf, 0, n);
			}
		} while (n != -1);
		fis.close();
		return complete.digest();
	}

	public static void main(String[] args) {
			File directory = new File("C:\\Users\\skasar\\Desktop\\original");
			// List<Filedetails> fileinfo = DBconnection.compareFile();
			File[] filinfo = directory.listFiles();
			File file1=new File("C:\\Users\\skasar\\Desktop\\kkkkk.txt");
			for (File filedetails : filinfo) {
		boolean flag;
		try {
			flag = CompareFilesbyByte(file1, filedetails);
			if (flag) {
				System.out.println("Similar file is " + filedetails);
				break;
			} else {
				System.out.println("No Similar File");
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
		}
		
	}
	}
}
