package Com.algorithm;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpSession;

import Com.database.DBconnection;

public class MatchContents {

	public static boolean[] match(File file, InputStream byt) throws IOException {
		boolean[] flags = new boolean[2];
		boolean flag = false;
		File directory = new File("C:\\Users\\skasar\\Desktop\\original\\");
		// List<Filedetails> fileinfo = DBconnection.compareFile();
		File[] filinfo = directory.listFiles();
		for (File filedetails : filinfo) {

			if (file.getName().equals(filedetails.getName())) {
				System.out.println("change your file name");
				flag = true;
				flags[0] = flag;
				flags[1] = flag;
				break;
			} else {
				// flags[0] = false;
				try {
					// System.out.println("MatchContents.match()");
					// System.err.println(file.getName());
					System.out.println("does exist (matchcontent) " + file.exists());
					System.out
							.println("File mame and its path is ==> " + file.getName() + " " + file.getAbsolutePath());
					boolean flag1 = Equality.CompareFilesbyByte(file, filedetails);
					System.out.println("flag 1 for file " + filedetails.getName() + " is " + flag1);

					if (flag1) {
						flags[1] = true;
						System.out.println("Similar file is " + filedetails);
						break;
					} else {
						System.out.println("No Similar File");
						// flags[1]=false;
					}
				} catch (IOException e) {
					e.printStackTrace();

				}
			}
		}
		return flags;

	}

	public static boolean sameContent(Path file1, Path file2) throws IOException {
		final long size = Files.size(file1);
		if (size != Files.size(file2))
			return false;

		if (size < 4096)
			return Arrays.equals(Files.readAllBytes(file1), Files.readAllBytes(file2));

		try (InputStream is1 = Files.newInputStream(file1); InputStream is2 = Files.newInputStream(file2)) {

			int data;
			while ((data = is1.read()) != -1)
				if (data != is2.read())
					return false;
		}

		return true;
	}

	public static boolean checkfilebyname(File file) {
		boolean flag = false;
		String path = "D:\\original\\";
		File file1 = new File(path + file.getName());
		flag = file1.exists();
		return flag;
	}

	public static Map<String, Boolean> matchcontents(String content,int userid) {
		boolean flag = false;
		Map<String,Boolean> map = new HashMap<String,Boolean>();
		String path = "D:\\original\\";
		File[] files = new File(path).listFiles();
		for (File file : files) {
			String content1 = ReadFileExample1.fileread(file);
			System.out.println("uploaded file====>" + content);
			System.out.println("exist file list====>" + content1);
			flag = content.equalsIgnoreCase(content1);
			if (flag) {
				System.out.println("similar file exists " + file.getName());
				
				map.put(file.getName(), flag);
				break;
			}
		}
		if(!flag)
		{
			map.put("no similar file", flag);
		}
		return map;
	}
}
