package Com.controller;

import java.io.File;
import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.DeleteObjectRequest;
import com.amazonaws.services.s3.model.GetObjectRequest;
import com.amazonaws.services.s3.model.PutObjectRequest;

public class AmazonStorage {
	public static String bucketName = "govind4567";
	public static String keyName = null;
	private static String uploadFileName = null;
	private static String accessKey = "AKIAIFMUHGCGD4MYYKUQ";
	private static String secretKey = "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";
	static boolean flag = false;

 static boolean uploadFile(File f1) {

		try {
			keyName = f1.getName();
			uploadFileName = f1.getName();
			AWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);

			AmazonS3 s3client = new AmazonS3Client(credentials);

			File f = new File(uploadFileName);
			// File encoded = Encryption.main(f);

			s3client.putObject(new PutObjectRequest(bucketName, keyName, f));
			System.out.println("done123");
			flag = true;

		} catch (AmazonServiceException aws) {
			System.out.println("Error massage" + aws.getMessage());
		} catch (AmazonClientException ace) {
			System.out.println("Error massage client " + ace.getMessage());
		}
		return flag;

	}

	static Boolean downloadFile(String bucketName, String keyName, String filepath) {

		try {
			AWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);
			AmazonS3 s3client = new AmazonS3Client(credentials);

			s3client.getObject(new GetObjectRequest(bucketName, keyName), new File(filepath + keyName));
			flag = true;
			System.out.println("file downloded from s3");
		} catch (AmazonServiceException aws) {
			System.out.println("Error massage" + aws.getMessage());
		} catch (AmazonClientException ace) {
			System.out.println("Error massage client " + ace.getMessage());
		}
		return flag;

	}

	static boolean deleteFile(String filename) {
		boolean flag = false;
		AWSCredentials credentials = new BasicAWSCredentials(accessKey, secretKey);
		AmazonS3 s3Client = new AmazonS3Client(credentials);
		try {
			keyName = filename;
			s3Client.deleteObject(new DeleteObjectRequest(bucketName, keyName));
			System.out.println("delete done");
			//flag = true;
		} catch (AmazonServiceException ase) {
			System.out.println("Caught an AmazonServiceException.");
			System.out.println("Error Message:    " + ase.getMessage());
			System.out.println("HTTP Status Code: " + ase.getStatusCode());
			System.out.println("AWS Error Code:   " + ase.getErrorCode());
			System.out.println("Error Type:       " + ase.getErrorType());
			System.out.println("Request ID:       " + ase.getRequestId());
		} catch (AmazonClientException ace) {
			System.out.println("Caught an AmazonClientException.");
			System.out.println("Error Message: " + ace.getMessage());
		}
		return flag;

	}

}