package Com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Com.database.DBconnection;
import Com.model.UserDetails;


@WebServlet("/Authentication")
public class Authentication extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	public Authentication() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String Email_Id = request.getParameter("Email_Id");
		String Password = request.getParameter("Password");
		System.out.println(Email_Id + "    " + Password);
		UserDetails u = DBconnection.getEmailPass(Email_Id, Password);
		
		System.out.println(u.getEmailid() + " " + u.getPassword());
		if (u != null) {

			if (Email_Id.equals(u.getEmailid()) && Password.equals(u.getPassword())) {
				HttpSession session = request.getSession();
				/*int userid=u.getUser_id();*/
				
				session.setAttribute("user", u);
				
				response.sendRedirect("FileUpload.jsp");

			}else {
				response.sendRedirect("Error.jsp");
			}

		}
		
	}
	

}
