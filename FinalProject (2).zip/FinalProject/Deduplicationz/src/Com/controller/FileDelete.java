package Com.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Com.database.DBconnection;
import Com.model.UserDetails;

/**
 * Servlet implementation class FileDelete
 */
@WebServlet("/FileDelete")
public class FileDelete extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FileDelete() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		/*HttpSession session = request.getSession();
		 int userid=u.getUser_id(); 

		UserDetails user = (UserDetails) session.getAttribute("user");
		int userid1 = user.getUser_id();
		int userid2 = Integer.parseInt(request.getParameter("uid"));*/
		int fileid = Integer.parseInt(request.getParameter("fid"));
		String filename = request.getParameter("filename");

		boolean flag = DBconnection.deleteFiles(fileid);
		if (flag) {
			AmazonStorage.deleteFile(filename);
			PrintWriter out = response.getWriter();
			out.println("<script type=\"text/javascript\">");
			out.println("alert('File Deleted Successfully');");
			out.println("location='Index.jsp';");
			out.println("</script>");
		} else {
			PrintWriter out = response.getWriter();
			out.println("<script type=\"text/javascript\">");
			out.println("alert('File Deletion Failed, Try again');");
			out.println("location='Index.jsp';");
			out.println("</script>");
		}

	}

}
