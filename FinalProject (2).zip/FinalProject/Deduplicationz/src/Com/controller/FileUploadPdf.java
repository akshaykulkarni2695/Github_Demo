package Com.controller;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import org.apache.commons.io.FileUtils;

import Com.algorithm.CipherExample;
import Com.algorithm.Cryptograpy;
import Com.algorithm.MatchContents;
import Com.algorithm.ReadFileExample1;
import Com.database.DBconnection;
import Com.model.Filedetails;

@WebServlet("/FileUpload")
@MultipartConfig
public class FileUploadPdf extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static String path1 = "D:\\original\\";

	// String securekey;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		// ServletContext context = getServletContext();

		final Part filePart = request.getPart("file");
		int userid = Integer.parseInt(request.getParameter("userid"));
		System.out.println(filePart.getSubmittedFileName());
		InputStream FileBytes = null;
		final PrintWriter writer = response.getWriter();
		try {

			/*
			 * if (!filePart.getContentType().equals("application/txt")) {
			 * writer.println("<br/> Invalid File"); return; }
			 * 
			 * else if (filePart.getSize()>3145728 ) { //2mb { writer.println(
			 * "<br/> File size too big"); return; } }
			 */
			FileBytes = filePart.getInputStream(); // to get the body of the
													// request as binary data
			final byte[] bytes = new byte[FileBytes.available()];
			FileBytes.read(bytes); // Storing the binary data in bytes array.

			Filedetails filedetails = new Filedetails();
			filedetails.setBytes(bytes);
			filedetails.setFilename(filePart.getSubmittedFileName());

			filedetails.setUser_id(userid);

			HttpSession session = request.getSession();
			session.setAttribute("fileinfo", filedetails);

			try {

				System.out.println("submitted name " + filePart.getSubmittedFileName());
				File file = new File(filePart.getSubmittedFileName());
				File file1 = new File("D:\\Demo\\" + file.getName());
				FileUtils.writeByteArrayToFile(new File(file1.getAbsolutePath()), bytes);
				System.out.println("file written in demo dir");
				ByteArrayInputStream byt = new ByteArrayInputStream(bytes);
				System.out.println("FileUploadPdf.doPost()");
				System.err.println("file name is ====> " + file.getName() + "  " + file.getAbsolutePath());
				System.out.println("does exist (controller) " + file.exists());
				String content1 = ReadFileExample1.fileread(file1);
				System.out.println("Content in uploaded file "+content1);
				boolean flag1 = MatchContents.checkfilebyname(file);
				System.out.println("flag1 " + flag1);
				Map<String, Boolean> map= new HashMap<String,Boolean>();
				boolean flag2=false;
				String similarFileName="";
				
				if (!flag1) {
					map= MatchContents.matchcontents(content1,userid);
					Iterator<Entry<String, Boolean>> itr= map.entrySet().iterator();
					Entry<String,Boolean> entry= itr.next();
					flag2= entry.getValue();
					similarFileName=entry.getKey();
					
				}
				
				System.out.println("flag2 " + flag2);
				if (flag1 == false && flag2 == false) {

					FileUtils.writeByteArrayToFile(new File(path1 + file), bytes);
					FileUtils.writeByteArrayToFile(file, bytes);

					DBconnection.insertFile(filedetails);

					String key = "squirrel123";
					try {
						// securekey= SelfProxyServer.getEncryptKey();
						CipherExample.main(file);

						// File f1 = Encryption.main(file);
						File f1 = Cryptograpy.main(file);
						AmazonStorage.uploadFile(f1);

					} catch (Throwable e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					PrintWriter out = response.getWriter();

					out.println("<script type=\"text/javascript\">");
					out.println("alert('File Uploaded Successfully On Cloud');");
					out.println("location='FileUpload.jsp';");
					out.println("</script>");

				} else if (flag1 == true) {
					PrintWriter out = response.getWriter();
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Rename your File And then Upload');");
					out.println("location='FileUpload.jsp';");
					out.println("</script>");

				} else if (flag2 == true) {
					int fid=DBconnection.getfid(similarFileName);
					int id=DBconnection.insertId(fid,userid);
					PrintWriter out = response.getWriter();
					out.println("<script type=\"text/javascript\">");
					out.println("alert('Similar File Exists : "+similarFileName+"');");
					out.println("location='FileUpload.jsp';");
					out.println("</script>");

				}

			} catch (Exception fnf) {
				writer.println("You  did not specify a file to upload");
				writer.println("<br/> ERROR: " + fnf.getMessage());
				fnf.printStackTrace();

			} finally {

				if (FileBytes != null) {
					FileBytes.close();
				}
				if (writer != null) {
					writer.close();
				}
			}
		} catch (Exception e) {
			// e.printStackTrace();
		}
	}
}