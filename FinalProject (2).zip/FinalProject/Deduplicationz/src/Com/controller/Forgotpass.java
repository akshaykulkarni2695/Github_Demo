package Com.controller;

import java.io.IOException;

import javax.mail.MessagingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import Com.database.DBconnection;
import Com.model.UserDetails;
import Com.utility.SendMailBySite;


@WebServlet("/Forgotpass")
public class Forgotpass extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Forgotpass() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String Email_Id = request.getParameter("Email_Id");

		UserDetails u = DBconnection.getEmail(Email_Id);

		if (u.getEmailid() != null) {
			try {

				SendMailBySite.sendPass("smtp.gmail.com", "587", "kasneticpvtltd@gmail.com", "kasnet12345", Email_Id,
						u.getPassword());
				// Database_con.insertSecCode(code);
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				// response.sendRedirect("Error.jsp");
				e.printStackTrace();
			}

			response.sendRedirect("login.jsp");
		} else {
			response.sendRedirect("EmailDoesntExist.jsp");
		}

	}

}
