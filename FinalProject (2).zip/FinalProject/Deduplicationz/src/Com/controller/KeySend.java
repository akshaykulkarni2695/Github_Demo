package Com.controller;

import java.io.IOException;
import java.util.List;
import java.util.Random;

import javax.mail.MessagingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Com.database.DBconnection;
import Com.model.UserDetails;
import Com.utility.SendMailBySite;

@WebServlet("/FileDownload")
public class KeySend extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public KeySend() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Random r = new Random();
		int max = 999999, min = 100000;
		int key = r.nextInt((max - min) + max);
		// Database_con.addCode(code);

		HttpSession session = request.getSession();
		/* int userid=u.getUser_id(); */

		UserDetails user = (UserDetails) session.getAttribute("user");
		String emailid = user.getEmailid();
		String fname = user.getFirstname();
		String lname = user.getLastname();
		String email = request.getParameter("email");
		// String name=request.getParameter("name");
		String fileid = request.getParameter("fid");
		String filename = request.getParameter("filename");

		/*
		 * Filedetails f1=(Filedetails)session.getAttribute("fileinfo"); int
		 * fileid=f1.getFid();
		 */

		try {
			// String email = null;
			// String emailid1 = request.getParameter("email");
			SendMailBySite.sendEmailToMainUser("smtp.gmail.com", "587", "project.varification@gmail.com", "Email@123",
					email, fname, lname, emailid, key,filename);
			List<Integer> useids = DBconnection.getOtherusersforfile(Integer.parseInt(fileid));
			for (Integer userid : useids) {
				UserDetails details = DBconnection.getalldetailsofuser(userid);
				SendMailBySite.sendEmailToMainUser("smtp.gmail.com", "587", "project.varification@gmail.com",
						"Email@123", details.getEmailid(), fname, lname, emailid, key, filename);
				
			}
			/*
			 * SendMailBySite.sendEmailkey("smtp.gmail.com", "587",
			 * "project.varification@gmail.com", "Email@123", emailid, key.);
			 */
			// Database_con.insertSecCode(code);
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			response.sendRedirect("Downloadfailed.jsp");
			e.printStackTrace();
		}
//		session.setAttribute("allowAccess", true);
		response.sendRedirect("Verify2.jsp?fid=" + fileid + "&filename=" + filename);

	}

}
