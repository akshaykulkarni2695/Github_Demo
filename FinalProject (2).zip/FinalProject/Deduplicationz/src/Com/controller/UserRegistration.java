package Com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.mail.MessagingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Com.database.DBconnection;
import Com.model.UserDetails;
import Com.utility.SendMailBySite;

@WebServlet("/UserRegistration")
public class UserRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UserRegistration() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub

		String firstname = request.getParameter("First_Name");
		String lastname = request.getParameter("Last_Name");
		String emailid = request.getParameter("Email_Id");
		String Password = request.getParameter("Password");
		String cpassword = request.getParameter("Confirm_Password");
		String Add = request.getParameter("Address");
		String Gender = request.getParameter("gender");
		String contactno = request.getParameter("contact");

		Random r = new Random();
		int max = 999999, min = 100000;
		int code = r.nextInt((max - min) + max);
		// Database_con.addCode(code);
		boolean flag = DBconnection.getRegEmail(emailid);
		System.out.println("email exists? " + flag);
		if (flag) {
			// response.sendRedirect("Index.jsp");
			PrintWriter out = response.getWriter();

			out.println("<script type=\"text/javascript\">");
			out.println("alert('Email Id exists...Register with different Email Id');");
			out.println("location='Register .jsp';");
			out.println("</script>");
		} else {
			try {
				SendMailBySite.sendEmail("smtp.gmail.com", "587", "project.varification@gmail.com", "Email@123",
						emailid, code);
				// Database_con.insertSecCode(code);
			} catch (MessagingException e) {
				// TODO Auto-generated catch block
				response.sendRedirect("Register.jsp");
				e.printStackTrace();
			}

			UserDetails d1 = new UserDetails();
			d1.setFirstname(firstname);
			d1.setLastname(lastname);
			d1.setEmailid(emailid);
			d1.setPassword(Password);
			d1.setPassword(cpassword);
			d1.setAdd(Add);
			d1.setGender(Gender);
			d1.setContactno(contactno);
			d1.setCode(code);

			HttpSession session = request.getSession();
			session.setAttribute("user", d1);
			RequestDispatcher rd = request.getRequestDispatcher("Verify.jsp");
			rd.include(request, response);
			// response.sendRedirect("Verify.jsp");
		}
	}

}
