package Com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import Com.database.DBconnection;
import Com.model.UserDetails;

@WebServlet("/verification")
public class verification extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession();
		UserDetails user = (UserDetails) session.getAttribute("user");

		String vcode = request.getParameter("vrcode");
		/*int vrcode = Integer.parseInt(vcode);*/
		/*
		 * int user_id = DBconnection.getMaxCode(); UserDetails u =
		 * DBconnection.getDetails(user_id);
		 */
		int vericode = user.getCode();
		
		if (vericode == user.getCode()) {

			/*UserDetails usr1 = new UserDetails();
			usr1.setFirstname(user.getFirstname());
			usr1.setLastname(user.getLastname());
			usr1.setEmailid(user.getEmailid());
			usr1.setPassword(user.getPassword());
			usr1.setAdd(user.getAdd());
			usr1.setGender(user.getGender());
			usr1.setContactno(user.getContactno());*/

			DBconnection.Register(user);
			int id1 = DBconnection.getMaxId();

			HttpSession session1 = request.getSession();
			session1.setAttribute("user_id", id1);

			response.sendRedirect("login.jsp");

		} else {
			response.sendRedirect("Verify.jsp");
		}

	}

}
