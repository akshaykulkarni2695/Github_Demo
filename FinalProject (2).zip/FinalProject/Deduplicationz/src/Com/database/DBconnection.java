package Com.database;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import Com.model.Filedetails;
import Com.model.UploadDetails;
import Com.model.UserDetails;

public class DBconnection {
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost:3306/deduplication";
	static final String USER = "root";
	static final String PASS = "root";

	public static Connection makeConnection() {
		Connection con = null;
		try {
			Class.forName(JDBC_DRIVER);
			con = DriverManager.getConnection(DB_URL, USER, PASS);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;

	}

	public static int Register(UserDetails d1) {
		Connection con = makeConnection();
		int i = 0;
		try {
			String sql = "INSERT INTO userdetails(First_Name,Last_Name, Email_Id, Password, Address, Gender, Contact_No) VALUES (?, ?, ?, ?, ?, ?, ?)";
			PreparedStatement p = con.prepareStatement(sql);
			p.setString(1, d1.getFirstname());
			p.setString(2, d1.getLastname());
			p.setString(3, d1.getEmailid());
			p.setString(4, d1.getPassword());
			p.setString(5, d1.getAdd());
			p.setString(6, d1.getGender());
			p.setString(7, d1.getContactno());
			int rowsInserted = p.executeUpdate();
			if (rowsInserted == 1) {
				System.out.println("A new user was inserted successfully!");

			}
		}

		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	public static UserDetails getEmailPass(String Email_Id, String Password) {
		UserDetails u = new UserDetails();

		Connection con = makeConnection();
		try {
			ResultSet rs2 = con.createStatement().executeQuery(
					"select * from userdetails where Email_Id='" + Email_Id + "' and Password='" + Password + "'");
			System.out.println(
					"select * from userdetails where Email_Id='" + Email_Id + "' and Password='" + Password + "'");
			while (rs2.next()) {

				u.setUser_id(rs2.getInt("user_id"));
				u.setFirstname(rs2.getString("First_Name"));
				u.setLastname(rs2.getString("Last_Name"));

				u.setEmailid(rs2.getString("Email_Id"));
				u.setPassword(rs2.getString("Password"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return u;

	}

	public static UserDetails getEmail(String Email_Id) {
		UserDetails u = new UserDetails();

		Connection con = makeConnection();
		try {
			ResultSet rs2 = con.createStatement()
					.executeQuery("select * from userdetails where Email_Id='" + Email_Id + "' ");
			System.out.println("select * from userdetails where Email_Id='" + Email_Id + "' ");
			while (rs2.next()) {

				u.setUser_id(rs2.getInt("user_id"));

				u.setEmailid(rs2.getString("Email_Id"));
				u.setPassword(rs2.getString("Password"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return u;

	}
	/*
	 * public static UserDetails getDetails(int user_id) { UserDetails u = null;
	 * Connection con = makeConnection(); try { ResultSet rs =
	 * con.createStatement().executeQuery("select * from user where user_id=" +
	 * user_id);
	 * 
	 * while (rs.next()) { u = new UserDetails();
	 * u.setCode(Integer.parseInt(rs.getString("vcode")));
	 * u.setFirstname(rs.getString("First_Name"));
	 * u.setLastname(rs.getString("Last_Name"));
	 * u.setPassword(rs.getString("Password"));
	 * u.setEmailid(rs.getString("Email_Id"));
	 * u.setAdd(rs.getString("Address")); u.setGender(rs.getString("Gender"));
	 * u.setContactno(rs.getString("Contact_No"));
	 * 
	 * } } catch (SQLException e) { // TODO Auto-generated catch block
	 * e.printStackTrace(); System.out.println(e); }
	 * 
	 * return u;
	 * 
	 * }
	 */

	/*
	 * public static int getMaxCode() { int user_id = 0; Connection con =
	 * makeConnection(); try { ResultSet rs = con.createStatement().
	 * executeQuery("select max(user_id) as user_id  from user "); while
	 * (rs.next()) { user_id = rs.getInt("user_id"); } } catch (SQLException e)
	 * { // TODO Auto-generated catch block e.printStackTrace(); }
	 * 
	 * return user_id;
	 * 
	 * }
	 */
	public static int getMaxId() {
		int user_id = 0;
		Connection conn = makeConnection();
		try {
			ResultSet rs1 = conn.createStatement().executeQuery("select max(user_id) as user_id  from userdetails ");
			while (rs1.next()) {
				user_id = rs1.getInt("user_id");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return user_id;

	}

	public static int checkLogin(UserDetails user) {
		int i = 0;
		String sql = "select user_id from userinformation where email_id=? and password=?";
		Connection con = makeConnection();
		ResultSet rs = null;
		try {
			PreparedStatement pstm = con.prepareStatement(sql);
			pstm.setString(1, user.getEmailid());
			pstm.setString(2, user.getPassword());
			rs = pstm.executeQuery();
			while (rs.next()) {
				i = rs.getInt("user_id");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return i;
	}

	public static void insertFile(Filedetails filedetails) {

		Connection con = makeConnection();

		PreparedStatement pstm = null;
		int i = 0;
		String sql = "INSERT INTO FilePath(User_id,FILE_NAME,FILE,Upload_Time,Upload_date) VALUES (?,?,?,curtime(),curdate())";

		try {
			pstm = con.prepareStatement(sql);
			pstm.setInt(1, filedetails.getUser_id());
			pstm.setString(2, filedetails.getFilename());
			pstm.setBytes(3, filedetails.getBytes());
			// byte[] array

			int cnt = pstm.executeUpdate();
			if (cnt == 1) {
				System.out.println("successful");
			} else {
				System.out.println("unsuccess");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public static List<UploadDetails> viewFile() {
		List<UploadDetails> filelist = new ArrayList<UploadDetails>();

		Connection con = makeConnection();
		String sql = "Select userdetails.User_id,userdetails.First_Name, userdetails.Last_Name,userdetails.Email_Id,FilePath.ID,FilePath.FILE_NAME,FilePath.Upload_Time,FilePath.Upload_date from userdetails INNER JOIN FilePath ON userdetails.User_id=FilePath.User_id;";
		try {
			Statement st = con.createStatement();
			ResultSet rs1 = st.executeQuery(sql);
			while (rs1.next()) {
				UploadDetails uploadfildetails = new UploadDetails();
				uploadfildetails.setUser_id(rs1.getInt("User_id"));
				// uploadfildetails.setFid(rs1.getInt("ID"));
				uploadfildetails.setFirstname(rs1.getString("First_Name"));
				uploadfildetails.setLastname(rs1.getString("Last_Name"));
				uploadfildetails.setEmailid(rs1.getString("Email_Id"));
				uploadfildetails.setFid(rs1.getInt("ID"));
				uploadfildetails.setFilename(rs1.getString("FILE_NAME"));
				uploadfildetails.setTime(rs1.getTime("Upload_Time"));
				uploadfildetails.setDate(rs1.getDate("Upload_date"));
				/* uploadfildetails.setBytes(rs1.getBytes("FILE")); */
				// uploadfildetails.setDescription(rs1.getString("DESCRIPTION"));
				filelist.add(uploadfildetails);
				System.out.println(filelist);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block.
			e.printStackTrace();
		}
		return filelist;

	}

	public static List<Filedetails> compareFile() throws IOException {
		List<Filedetails> fileinfo = new ArrayList<Filedetails>();

		Connection con = makeConnection();
		String sql = "Select *from Filepath";
		try {
			Statement st = con.createStatement();
			ResultSet rs3 = st.executeQuery(sql);
			while (rs3.next()) {
				Filedetails filefetch = new Filedetails();
				filefetch.setFid(rs3.getInt("ID"));
				filefetch.setFilename(rs3.getString("FILE_NAME"));
				filefetch.setBytes(rs3.getBytes("FILE"));
				fileinfo.add(filefetch);
				Blob blob = rs3.getBlob("FILE");
				InputStream in = blob.getBinaryStream();
				File file = new File(rs3.getString("FILE_NAME"));
				filefetch.setFile(file);
				System.out.println(fileinfo);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return fileinfo;
	}

	/*
	 * public static String getDecryptKey(int uid, String filename) { // TODO
	 * Auto-generated method stub String key=""; try { Connection
	 * con=makeConnection(); String sql =
	 * "select securekey from FilePath where UId='" + uid + "' and FileName='" +
	 * filename + "'"; System.out.println(sql); Statement st =
	 * con.createStatement(); ResultSet rs3 = st.executeQuery(sql);
	 * 
	 * 
	 * while(rs3.next()) { key=Integer.toString(rs3.getInt("securekey"));
	 * System.out.println("key"+key); }
	 * 
	 * 
	 * } catch (SQLException e) {
	 * 
	 * e.printStackTrace(); }
	 * 
	 * return key; }
	 */
	public static List<UploadDetails> showFile() {
		List<UploadDetails> filelist = new ArrayList<UploadDetails>();

		Connection con = makeConnection();
		String sql = "Select userdetails.User_id,userdetails.First_Name,userdetails.Email_Id,FilePath.ID,FilePath.FILE_NAME from userdetails INNER JOIN FilePath ON userdetails.User_id=FilePath.User_id;";

		try {
			Statement st = con.createStatement();
			ResultSet rs2 = st.executeQuery(sql);
			while (rs2.next()) {
				UploadDetails uploadfildetails = new UploadDetails();
				uploadfildetails.setUser_id(rs2.getInt("User_id"));
				uploadfildetails.setFirstname(rs2.getString("First_Name"));
				uploadfildetails.setEmailid(rs2.getString("Email_Id"));
				uploadfildetails.setFid(rs2.getInt("ID"));
				// uploadfildetails.setFirstname(rs1.getString("First_Name"));
				// uploadfildetails.setLastname(rs1.getString("Last_Name"));

				uploadfildetails.setFilename(rs2.getString("FILE_NAME"));
				/* uploadfildetails.setBytes(rs1.getBytes("FILE")); */
				// uploadfildetails.setDescription(rs1.getString("DESCRIPTION"));
				filelist.add(uploadfildetails);
				System.out.println(filelist);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block.
			e.printStackTrace();
		}
		return filelist;

	}

	public static Filedetails fileDownload(String fid) throws IOException {

		Filedetails fd = null;
		String sql = "select FILE from filepath where ID=" + fid;
		Connection con = makeConnection();
		Statement st;
		try {
			st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {

				fd = new Filedetails();
				fd.setFid(rs.getInt("ID"));
				fd.setFilename(rs.getString("FILE_NAME"));
				// fd.setBytes(rs.getBytes("file"));
				Blob blob = rs.getBlob("FILE");
				InputStream inputStream = blob.getBinaryStream();
				int fileLength = inputStream.available();

				System.out.println("fileLength = " + fileLength);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return fd;

	}

	public static List<UploadDetails> showdeleteFiles() {
		List<UploadDetails> filelist = new ArrayList<UploadDetails>();

		Connection con = makeConnection();
		String sql = "Select * from filepath;";
		try {
			Statement st = con.createStatement();
			ResultSet rs2 = st.executeQuery(sql);
			while (rs2.next()) {
				UploadDetails uploadfildetails = new UploadDetails();
				uploadfildetails.setUser_id(rs2.getInt("User_id"));
				uploadfildetails.setFid(rs2.getInt("ID"));
				uploadfildetails.setFilename(rs2.getString("FILE_NAME"));
				filelist.add(uploadfildetails);
				System.out.println(filelist);
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block.
			e.printStackTrace();
		}
		return filelist;

	}

	public static boolean deleteFiles(int fileid) {
		boolean flag = false;
		Connection con = makeConnection();
		String sql = "delete from filepath where ID=?";
		try {
			PreparedStatement ps = con.prepareStatement(sql);
			ps.setInt(1, fileid);
			int rowsDeleted = ps.executeUpdate();
			if (rowsDeleted > 0) {
				System.out.println("A file was deleted successfully!");
				flag = true;
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;

	}

	public static boolean getRegEmail(String emailid) {
		boolean flag = false;
		Connection con = makeConnection();
		String sql = "Select *from userdetails where Email_Id='" + emailid + "'";
		System.out.println("Select *from userdetails where Email_Id='" + emailid + "'");
		Statement st = null;
		ResultSet rs = null;

		try {
			st = con.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				flag = true;

			}
			System.out.println("flag in email check method is " + flag);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return flag;
	}

	public static int getfid(String name) {
		Connection con = makeConnection();
		int i = 0;
		String sql = "select ID from filepath where FILE_NAME= '" + name + " '";
		Statement st = null;
		ResultSet rs = null;
		try {
			st = con.createStatement();
			rs = st.executeQuery(sql);
			while (rs.next()) {
				i = rs.getInt("ID");

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return i;
	}

	public static int insertId(int fid, int userid) {
		int i = 0;
		Connection con = makeConnection();
		String sql = "insert into linkfiletouser(ID,User_id)values(?,?)";
		PreparedStatement pstm = null;
		try {
			pstm = con.prepareStatement(sql);
			pstm.setInt(1, fid);
			pstm.setInt(2, userid);
			int rowsInserted = pstm.executeUpdate();
			if (rowsInserted == 1) {
				System.out.println("A new user was inserted successfully!");

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return i;
	}

	public static List<Integer> getOtherusersforfile(int fileid) {
		List<Integer> userids = new ArrayList<Integer>();
		Connection con = makeConnection();
		String sql = "select User_id from linkfiletouser where ID=? ";
		PreparedStatement pstm = null;
		try {
			pstm = con.prepareStatement(sql);

			pstm.setInt(1, fileid);
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				userids.add(rs.getInt("User_id"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return userids;
	}

	public static UserDetails getalldetailsofuser(int userid) {
		Connection con = makeConnection();
		UserDetails details = new UserDetails();
		String sql = "select * from userdetails where User_id=" + userid;
		Statement st;
		try {
			st = con.createStatement();
			ResultSet rs = st.executeQuery(sql);
			while (rs.next()) {
				details.setUser_id(rs.getInt("User_id"));
				details.setEmailid(rs.getString("Email_Id"));
				details.setFirstname(rs.getString("First_Name"));

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return details;

	}
}
