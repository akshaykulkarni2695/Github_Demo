package Com.model;

import java.io.File;
import java.io.InputStream;
import java.sql.Date;
import java.sql.Time;

public class Filedetails {
	int fid, User_id, securekey;
	private String filename;
	private byte[] bytes;
	private Date Date;
	private Time time;


	public Date getDate() {
		return Date;
	}

	public void setDate(Date date) {
		Date = date;
	}

	public Time getTime() {
		return time;
	}

	public void setTime(Time time) {
		this.time = time;
	}

	private File file;

	public int getSecurekey() {
		return securekey;
	}

	public void setSecurekey(int securekey) {
		this.securekey = securekey;
	}

	public int getUser_id() {
		return User_id;
	}

	public void setUser_id(int user_id) {
		User_id = user_id;
	}

	public int getFid() {
		return fid;
	}

	public void setFid(int fid) {
		this.fid = fid;
	}

	public String getFilename() {
		return filename;
	}

	public void setFilename(String filename) {
		this.filename = filename;
	}

	public byte[] getBytes() {
		return bytes;
	}

	public void setBytes(byte[] bytes) {
		this.bytes = bytes;
	}

	public InputStream getInputStream() {
		// TODO Auto-generated method stub
		return null;
	}

	public File getFile() {
		return file;
	}

	public void setFile(File file) {
		this.file = file;
	}
}
