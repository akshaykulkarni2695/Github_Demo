package Com.model;

public class Securekey {
	int fid, User_id,securekey;

	public int getFid() {
		return fid;
	}

	public void setFid(int fid) {
		this.fid = fid;
	}

	public int getUser_id() {
		return User_id;
	}

	public void setUser_id(int user_id) {
		User_id = user_id;
	}

	public int getSecurekey() {
		return securekey;
	}

	public void setSecurekey(int securekey) {
		this.securekey = securekey;
	}
}
